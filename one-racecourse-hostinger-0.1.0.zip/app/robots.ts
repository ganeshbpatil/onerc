import type { MetadataRoute } from "next";
import { site } from "@/content/project";

export default function robots(): MetadataRoute.Robots {
  return { rules: [{ userAgent: "*", allow: "/", disallow: ["/api/", "/thank-you"] }], sitemap: `${site.url}/sitemap.xml`, host: site.url };
}
